---
markmap:
  colorFreezeLevel: 2
  color: '#000000'
  
---

# Week 2 Report

## Team member details

## Project Management Details

- WBS
- Tabular Gantt Chart
- Gantt Chart

## Abstract

## Motivated Design

## Requirements

- Input Requirements
- Output Requirements
- Power Requirements
- Logistical Requirements
- Environmental Requirements
- Site (Usage Site) Requirements
- Structural Requirements
- Time Requirements
- Time to Market Requirements
- Life Time Requirements
- End of Life Requirements
- Other Non-functional Requirements

## Specifications

- Energy Specifications
- Space Specifications
- Cost Specifications
- Performance Specifications
- Manpower Specifications
- Prototype Specifications
- Milestone Specifications

## Design Cycle 1

- Engineering Drawings

## Appendices

- Appendix 1: Document ID
- Appendix 2: Document Statistics
- Appendix 3: Readability Indices